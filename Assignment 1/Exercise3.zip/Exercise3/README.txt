SOEN487 Winter 2017 Assignment 1 Excercise 3
Submitted by Samantha Graham #21120689

To run:

1. Open project in Netbeans.
2. Click Run (F6). Output will appear in Netbeans' output window