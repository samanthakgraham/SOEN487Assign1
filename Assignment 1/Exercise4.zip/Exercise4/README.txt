SOEN487 Winter 2017 Assignment 1 Excercise 4
Submitted by Samantha Graham #21120689

To run:

1. Open project in Netbeans.
2. Optional step: Right-click and Run ProductMarshalling.java and WarehouseItemMarshalling.java. These will create inventory.xml and products.xml
3. Update INVENTORY_FILE_LOCATION in Warehouse.java and PRODUCT_FILE_LOCATION and ORDER_FILE_LOCATION in Manufacturer.java so that they point to those files on your system.
3. Click Run (F6). The index.jsp will open in your default browser window.
4. Fill out the order form as desired and click submit. The list of shipped and non-shipped items will appear below the form.