SOEN487 Winter 2017 Assignment 1 Excercise 2
Submitted by Samantha Graham #21120689

To run:

1. Open TemperatureConverterWSJSPClient in Netbeans.
2. Click Run (F6). Project will open in your default browser.